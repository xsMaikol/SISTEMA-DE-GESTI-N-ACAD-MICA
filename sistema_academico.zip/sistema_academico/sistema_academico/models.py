
"""MODELO: Clases del Sistema de Gestión Académica.

Implementa:
- Programación Orientada a Objetos (POO).
- Herencia.
- Polimorfismo.
- Encapsulamiento básico.
- Métodos de clase y métodos estáticos.
- Conversión de objetos a diccionarios.
"""

from datetime import date


# ==========================================================
# CLASE BASE
# ==========================================================

class ModeloBase:
    """Clase principal de los modelos del sistema."""

    def __init__(self, id_registro):
        self.id = int(id_registro)

    @classmethod
    def desde_diccionario(cls, datos):
        """Convierte un diccionario en un objeto."""
        datos = datos.copy()
        identificador = datos.pop("id")

        return cls(identificador, **datos)

    def a_diccionario(self):
        """Convierte los atributos básicos a diccionario."""
        return {
            "id": self.id
        }

    def etiqueta(self):
        """Devuelve una descripción del registro."""
        return f"{type(self).__name__} #{self.id}"


# ==========================================================
# CLASE PERSONA
# ==========================================================

class Persona(ModeloBase):
    """Representa los datos generales de una persona."""

    def __init__(self, id_registro, nombre, apellido, email):
        super().__init__(id_registro)

        self.nombre = str(nombre).strip()
        self.apellido = str(apellido).strip()
        self.email = str(email).strip().lower()

    def a_diccionario(self):
        """Devuelve los datos de la persona."""
        return {
            **super().a_diccionario(),
            "nombre": self.nombre,
            "apellido": self.apellido,
            "email": self.email
        }

    def etiqueta(self):
        """Devuelve el nombre completo de la persona."""
        return f"{self.nombre} {self.apellido}"


# ==========================================================
# CLASE ESTUDIANTE
# ==========================================================

class Estudiante(Persona):
    """Representa un estudiante del sistema académico."""

    def __init__(
        self,
        id_registro,
        nombre,
        apellido,
        email,
        carnet="",
        carrera=""
    ):
        super().__init__(
            id_registro,
            nombre,
            apellido,
            email
        )

        self.carnet = str(carnet).strip()
        self.carrera = str(carrera).strip()

    def a_diccionario(self):
        """Convierte los datos del estudiante a diccionario."""
        return {
            **super().a_diccionario(),
            "carnet": self.carnet,
            "carrera": self.carrera
        }

    def etiqueta(self):
        """Muestra la información principal del estudiante."""
        return (
            f"{super().etiqueta()} | "
            f"Carnet: {self.carnet} | "
            f"Carrera: {self.carrera}"
        )


# ==========================================================
# CLASE MATERIA
# ==========================================================

class Materia(ModeloBase):
    """Representa una asignatura académica."""

    CUPOS_MAXIMOS = 30
    NOTA_APROBACION = 14

    def __init__(
        self,
        id_registro,
        nombre,
        codigo,
        creditos=0,
        cupos=0
    ):
        super().__init__(id_registro)

        self.nombre = str(nombre).strip()
        self.codigo = str(codigo).strip().upper()

        self.creditos = int(creditos)
        self.cupos = int(cupos)

        if self.creditos < 0:
            raise ValueError(
                "Los créditos no pueden ser negativos."
            )

        if not 0 <= self.cupos <= self.CUPOS_MAXIMOS:
            raise ValueError(
                f"Los cupos deben estar entre 0 y "
                f"{self.CUPOS_MAXIMOS}."
            )

    @staticmethod
    def es_nota_valida(valor):
        """Comprueba si una nota está entre 0 y 20."""
        try:
            nota = float(valor)
            return 0 <= nota <= 20

        except (ValueError, TypeError):
            return False

    def hay_cupo(self):
        """Comprueba si existen cupos disponibles."""
        return self.cupos > 0

    def ocupar_cupo(self):
        """Disminuye un cupo al matricular un estudiante."""
        if not self.hay_cupo():
            return False

        self.cupos -= 1
        return True

    def liberar_cupo(self):
        """Recupera un cupo al retirar una matrícula."""
        if self.cupos >= self.CUPOS_MAXIMOS:
            return False

        self.cupos += 1
        return True

    def a_diccionario(self):
        """Convierte la materia a diccionario."""
        return {
            **super().a_diccionario(),
            "nombre": self.nombre,
            "codigo": self.codigo,
            "creditos": self.creditos,
            "cupos": self.cupos
        }

    def etiqueta(self):
        """Devuelve una descripción de la materia."""
        return (
            f"{self.nombre} | "
            f"Código: {self.codigo} | "
            f"Créditos: {self.creditos} | "
            f"Cupos: {self.cupos}"
        )


# ==========================================================
# CLASE MATRÍCULA
# ==========================================================

class Matricula(ModeloBase):
    """Representa la matrícula de un estudiante."""

    def __init__(
        self,
        id_registro,
        estudiante_id,
        materia_id,
        periodo,
        nota=0,
        fecha=""
    ):
        super().__init__(id_registro)

        self.estudiante_id = int(estudiante_id)
        self.materia_id = int(materia_id)

        self.periodo = str(periodo).strip()
        self.nota = float(nota)
        self.fecha = fecha or date.today().isoformat()

        if not Materia.es_nota_valida(self.nota):
            raise ValueError(
                "La nota debe estar entre 0 y 20."
            )

    def esta_aprobada(self):
        """Determina si el estudiante aprobó la materia."""
        return self.nota >= Materia.NOTA_APROBACION

    def estado(self):
        """Devuelve el estado académico de la matrícula."""
        if self.nota == 0:
            return "Pendiente"

        if self.esta_aprobada():
            return "Aprobado"

        return "Reprobado"

    def a_diccionario(self):
        """Convierte los datos de la matrícula a diccionario."""
        return {
            **super().a_diccionario(),
            "estudiante_id": self.estudiante_id,
            "materia_id": self.materia_id,
            "periodo": self.periodo,
            "nota": self.nota,
            "fecha": self.fecha
        }

    def etiqueta(self):
        """Devuelve la información principal de la matrícula."""
        return (
            f"Estudiante #{self.estudiante_id} | "
            f"Materia #{self.materia_id} | "
            f"Período: {self.periodo} | "
            f"Nota: {self.nota:g} | "
            f"Estado: {self.estado()}"
        )
