
"""PERSISTENCIA: Gestión de archivos JSON del Sistema Académico.

Permite:
- Crear automáticamente la carpeta de datos.
- Leer registros almacenados.
- Guardar información en formato JSON.
- Evitar archivos parcialmente escritos.
"""

import json
from pathlib import Path


# ==========================================================
# CLASE GESTOR JSON
# ==========================================================

class GestorJSON:
    """Administra la lectura y escritura de archivos JSON."""

    def __init__(self, nombre):
        """Configura la ubicación del archivo JSON."""

        carpeta_base = Path(__file__).resolve().parent.parent
        carpeta_datos = carpeta_base / "data"

        # Crear la carpeta si todavía no existe.
        carpeta_datos.mkdir(parents=True, exist_ok=True)

        # Definir la ruta del archivo.
        self.ruta = carpeta_datos / nombre

        # Crear un archivo JSON vacío si no existe.
        if not self.ruta.exists():
            self.guardar([])

    def leer(self):
        """Lee los registros almacenados en el archivo JSON."""

        try:
            with self.ruta.open(
                "r",
                encoding="utf-8"
            ) as archivo:
                registros = json.load(archivo)

            if not isinstance(registros, list):
                raise ValueError(
                    "El archivo JSON debe contener una lista."
                )

            return registros

        except json.JSONDecodeError as error:
            raise ValueError(
                f"El archivo {self.ruta.name} contiene "
                "datos JSON inválidos."
            ) from error

    def guardar(self, registros):
        """Guarda los registros de forma segura."""

        if not isinstance(registros, list):
            raise ValueError(
                "Los registros deben almacenarse en una lista."
            )

        # Archivo temporal para evitar escrituras incompletas.
        temporal = self.ruta.with_suffix(".tmp")

        try:
            with temporal.open(
                "w",
                encoding="utf-8"
            ) as archivo:
                json.dump(
                    registros,
                    archivo,
                    ensure_ascii=False,
                    indent=2
                )

            # Reemplazar el archivo original.
            temporal.replace(self.ruta)

        finally:
            # Eliminar el temporal si quedó después de un error.
            if temporal.exists():
                temporal.unlink()
