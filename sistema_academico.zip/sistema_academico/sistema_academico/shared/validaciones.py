
"""VALIDACIONES: Funciones auxiliares del Sistema Académico."""

import re


# ==========================================================
# VALIDACIÓN DE CORREO ELECTRÓNICO
# ==========================================================

def es_email_valido(email):
    """Verifica que un correo tenga un formato válido."""

    if not isinstance(email, str):
        return False

    email = email.strip()

    if not email:
        return False

    patron = r"^[^\s@]+@[^\s@]+\.[^\s@]+$"

    return bool(re.fullmatch(patron, email))
