
"""VISTA: Menús e interacción del Sistema de Gestión Académica.

Para ejecutar el programa:
    python main.py
"""

import views as c


# ==========================================================
# FUNCIONES AUXILIARES
# ==========================================================

def pedir(texto, actual=None):
    """Solicita un dato al usuario."""
    sufijo = f" [{actual}]" if actual is not None else ""

    valor = input(f"{texto}{sufijo}: ").strip()

    if valor:
        return valor

    if actual is not None:
        return str(actual)

    return ""


def pedir_id(texto="ID"):
    """Solicita un identificador numérico válido."""
    try:
        identificador = int(input(f"{texto}: ").strip())

        if identificador <= 0:
            print("ERROR: El ID debe ser mayor que cero.")
            return None

        return identificador

    except ValueError:
        print("ERROR: Debes escribir un número entero.")
        return None


def mostrar_lista(objetos):
    """Muestra los registros disponibles."""
    if not objetos:
        print("\nNo hay registros disponibles.")
        return

    print("\n---------- REGISTROS ----------")

    for objeto in objetos:
        print(f"#{objeto.id} | {objeto.etiqueta()}")

    print("-------------------------------")


def mostrar_detalle(objeto):
    """Muestra la información completa de un registro."""
    if objeto is None:
        print("ERROR: Registro no encontrado.")
        return

    print(f"\n--- {objeto.etiqueta()} ---")

    for campo, valor in objeto.a_diccionario().items():
        print(f"{campo.capitalize()}: {valor}")


def mensaje(resultado):
    """Muestra el resultado de una operación."""
    exito, texto = resultado

    if exito:
        print(f"\nOK: {texto}")
    else:
        print(f"\nERROR: {texto}")


def confirmar(texto="¿Confirmar operación?"):
    """Solicita confirmación antes de una acción."""
    respuesta = input(f"{texto} (s/n): ").strip().lower()
    return respuesta == "s"


# ==========================================================
# MENÚ DE ESTUDIANTES Y MATERIAS
# ==========================================================

def menu_entidad(tipo):
    """Gestiona las operaciones CRUD de una entidad."""

    estudiante = tipo == "estudiantes"

    if estudiante:
        obtener = c.obtener_estudiantes
        uno = c.obtener_estudiante
        buscar = c.buscar_estudiantes
        crear = c.crear_estudiante
        actualizar = c.actualizar_estudiante
        borrar = c.eliminar_estudiante

        campos = (
            "nombre",
            "apellido",
            "email",
            "carnet",
            "carrera"
        )

    else:
        obtener = c.obtener_materias
        uno = c.obtener_materia
        buscar = c.buscar_materias
        crear = c.crear_materia
        actualizar = c.actualizar_materia
        borrar = c.eliminar_materia

        campos = (
            "nombre",
            "codigo",
            "creditos",
            "cupos"
        )

    while True:
        print(f"\n========== {tipo.upper()} ==========")
        print("1. Crear registro")
        print("2. Mostrar todos")
        print("3. Buscar registro")
        print("4. Consultar por ID")
        print("5. Actualizar registro")
        print("6. Eliminar registro")
        print("0. Volver al menú principal")

        opcion = input("\nSeleccione una opción: ").strip()

        # CREAR
        if opcion == "1":
            print("\n--- NUEVO REGISTRO ---")

            datos = {}

            for campo in campos:
                datos[campo] = pedir(campo.capitalize())

            mensaje(crear(datos))

        # MOSTRAR TODOS
        elif opcion == "2":
            mostrar_lista(obtener())

        # BUSCAR
        elif opcion == "3":
            texto = pedir("Texto a buscar")
            mostrar_lista(buscar(texto))

        # CONSULTAR POR ID
        elif opcion == "4":
            identificador = pedir_id()

            if identificador is not None:
                objeto = uno(identificador)
                mostrar_detalle(objeto)

        # ACTUALIZAR
        elif opcion == "5":
            identificador = pedir_id()

            if identificador is None:
                continue

            objeto = uno(identificador)

            if objeto is None:
                print("ERROR: Registro no encontrado.")
                continue

            print("\nPresiona ENTER para mantener el valor actual.")

            cambios = {}

            for campo in campos:
                valor_actual = getattr(objeto, campo)

                cambios[campo] = pedir(
                    campo.capitalize(),
                    valor_actual
                )

            mensaje(actualizar(identificador, cambios))

        # ELIMINAR
        elif opcion == "6":
            identificador = pedir_id()

            if identificador is None:
                continue

            if uno(identificador) is None:
                print("ERROR: Registro no encontrado.")
                continue

            if confirmar("¿Deseas eliminar este registro?"):
                mensaje(borrar(identificador))
            else:
                print("Operación cancelada.")

        # VOLVER
        elif opcion == "0":
            return

        else:
            print("ERROR: Opción inválida.")


# ==========================================================
# MENÚ DE MATRÍCULAS
# ==========================================================

def menu_matriculas():
    """Gestiona las matrículas y calificaciones."""

    while True:
        print("\n========== MATRÍCULAS ==========")
        print("1. Matricular estudiante")
        print("2. Mostrar matrículas")
        print("3. Registrar calificación")
        print("4. Consultar certificado")
        print("5. Retirar matrícula")
        print("0. Volver al menú principal")

        opcion = input("\nSeleccione una opción: ").strip()

        # MATRICULAR
        if opcion == "1":
            print("\n--- NUEVA MATRÍCULA ---")

            estudiante_id = pedir_id("ID del estudiante")
            materia_id = pedir_id("ID de la materia")

            if estudiante_id is None or materia_id is None:
                continue

            periodo = pedir("Período académico (ej. 2026-1)")

            datos = {
                "estudiante_id": estudiante_id,
                "materia_id": materia_id,
                "periodo": periodo,
                "nota": 0
            }

            mensaje(c.crear_matricula(datos))

        # MOSTRAR MATRÍCULAS
        elif opcion == "2":
            mostrar_lista(c.obtener_matriculas())

        # REGISTRAR NOTA
        elif opcion == "3":
            identificador = pedir_id("ID de la matrícula")

            if identificador is None:
                continue

            nota = pedir("Calificación de 0 a 20")

            mensaje(c.registrar_nota(identificador, nota))

        # CERTIFICADO
        elif opcion == "4":
            identificador = pedir_id("ID de la matrícula")

            if identificador is None:
                continue

            certificado = c.certificado(identificador)

            if certificado:
                print("\n========== CERTIFICADO ==========")
                print(certificado)
                print("=================================")
            else:
                print("ERROR: Matrícula no encontrada.")

        # RETIRAR MATRÍCULA
        elif opcion == "5":
            identificador = pedir_id("ID de la matrícula")

            if identificador is None:
                continue

            if confirmar("¿Deseas retirar esta matrícula?"):
                mensaje(c.retirar_matricula(identificador))
            else:
                print("Operación cancelada.")

        # VOLVER
        elif opcion == "0":
            return

        else:
            print("ERROR: Opción inválida.")


# ==========================================================
# RESUMEN ACADÉMICO
# ==========================================================

def menu_resumen():
    """Muestra las estadísticas generales del sistema."""

    datos = c.resumen()

    print("\n========== RESUMEN ACADÉMICO ==========")

    print(f"Total de estudiantes: {datos['estudiantes']}")

    carreras = ", ".join(datos["carreras"]) or "Ninguna"
    print(f"Carreras registradas: {carreras}")

    print("\n--- MATERIAS SIN CUPO ---")
    mostrar_lista(datos["sin_cupo"])

    print(f"\nMatrículas aprobadas: {datos['aprobadas']}")

    print("=======================================")


# ==========================================================
# MENÚ PRINCIPAL
# ==========================================================

def main():
    """Función principal del sistema académico."""

    while True:
        print("\n==========================================")
        print("       SISTEMA DE GESTIÓN ACADÉMICA")
        print("==========================================")
        print("1. Gestión de estudiantes")
        print("2. Gestión de materias")
        print("3. Gestión de matrículas")
        print("4. Resumen académico")
        print("0. Salir")
        print("==========================================")

        opcion = input("Seleccione una opción: ").strip()

        if opcion == "1":
            menu_entidad("estudiantes")

        elif opcion == "2":
            menu_entidad("materias")

        elif opcion == "3":
            menu_matriculas()

        elif opcion == "4":
            menu_resumen()

        elif opcion == "0":
            print("\nGracias por utilizar el sistema académico.")
            print("Programa finalizado.")
            break

        else:
            print("ERROR: Seleccione una opción válida.")


# ==========================================================
# EJECUCIÓN DEL PROGRAMA
# ==========================================================

if __name__ == "__main__":
    try:
        main()

    except (KeyboardInterrupt, EOFError):
        print("\nPrograma finalizado por el usuario.")
