
"""CONTROLADOR: Sistema de Gestión Académica.

Gestiona las operaciones CRUD, validaciones,
matrículas, calificaciones y persistencia JSON.

No utiliza input() ni print().
"""

from datetime import date

from models import Estudiante, Materia, Matricula
from shared.json_manager import GestorJSON
from shared.validaciones import es_email_valido


# ==========================================================
# GESTORES DE ALMACENAMIENTO
# ==========================================================

gestor_estudiantes = GestorJSON("estudiantes.json")
gestor_materias = GestorJSON("materias.json")
gestor_matriculas = GestorJSON("matriculas.json")


# ==========================================================
# FUNCIONES GENERALES
# ==========================================================

def leer_objetos(gestor, modelo):
    """Obtiene registros JSON y los convierte en objetos."""
    return [
        modelo.desde_diccionario(datos)
        for datos in gestor.leer()
    ]


def obtener_por_id(gestor, modelo, id_registro):
    """Busca un registro por su identificador."""
    return next(
        (
            objeto
            for objeto in leer_objetos(gestor, modelo)
            if objeto.id == int(id_registro)
        ),
        None
    )


def buscar(gestor, modelo, termino, campos):
    """Busca coincidencias en los campos indicados."""
    termino = str(termino).strip().casefold()

    return [
        objeto
        for objeto in leer_objetos(gestor, modelo)
        if any(
            termino in str(
                getattr(objeto, campo, "")
            ).casefold()
            for campo in campos
        )
    ]


def siguiente_id(gestor):
    """Calcula el siguiente identificador disponible."""
    return max(
        (registro["id"] for registro in gestor.leer()),
        default=0
    ) + 1


def guardar_nuevo(gestor, objeto):
    """Agrega un nuevo registro al archivo JSON."""
    registros = gestor.leer()
    registros.append(objeto.a_diccionario())
    gestor.guardar(registros)


def reemplazar(gestor, objeto):
    """Actualiza un registro existente."""
    registros = gestor.leer()

    for indice, registro in enumerate(registros):
        if registro["id"] == objeto.id:
            registros[indice] = objeto.a_diccionario()
            gestor.guardar(registros)
            return True

    return False


def eliminar(gestor, identificador):
    """Elimina un registro mediante su ID."""
    registros = gestor.leer()

    nuevos = [
        registro
        for registro in registros
        if registro["id"] != int(identificador)
    ]

    if len(nuevos) == len(registros):
        return False

    gestor.guardar(nuevos)
    return True


def ids_registrados(gestor):
    """Devuelve un conjunto de identificadores."""
    return {
        registro["id"]
        for registro in gestor.leer()
    }


def indice_por_id(objetos):
    """Crea un diccionario para consultar por ID."""
    return {
        objeto.id: objeto
        for objeto in objetos
    }


# ==========================================================
# GESTIÓN DE ESTUDIANTES
# ==========================================================

CAMPOS_ESTUDIANTE = (
    "nombre",
    "apellido",
    "email",
    "carnet",
    "carrera"
)


def carnets_registrados(excepto_id=None):
    """Obtiene los carnets existentes sin duplicados."""
    return {
        registro["carnet"].strip().upper()
        for registro in gestor_estudiantes.leer()
        if registro["id"] != excepto_id
    }


def validar_estudiante(datos, id_actual=None):
    """Valida los datos de un estudiante."""

    for campo in ("nombre", "apellido", "email", "carnet"):
        if not str(datos.get(campo, "")).strip():
            return f"El campo {campo} es obligatorio."

    email = str(datos["email"]).strip().casefold()
    carnet = str(datos["carnet"]).strip().upper()

    if not es_email_valido(email):
        return "Correo electrónico inválido."

    if carnet in carnets_registrados(id_actual):
        return "El carnet ya está registrado."

    emails = {
        registro["email"].strip().casefold()
        for registro in gestor_estudiantes.leer()
        if registro["id"] != id_actual
    }

    if email in emails:
        return "El correo electrónico ya está registrado."

    return None


def crear_estudiante(datos):
    """Registra un nuevo estudiante."""
    error = validar_estudiante(datos)

    if error:
        return False, error

    valores = {
        campo: str(datos.get(campo, "")).strip()
        for campo in CAMPOS_ESTUDIANTE
    }

    estudiante = Estudiante(
        siguiente_id(gestor_estudiantes),
        **valores
    )

    guardar_nuevo(gestor_estudiantes, estudiante)
    return True, "Estudiante registrado correctamente."


def obtener_estudiantes():
    """Devuelve todos los estudiantes."""
    return leer_objetos(gestor_estudiantes, Estudiante)


def obtener_estudiante(id_registro):
    """Obtiene un estudiante por su ID."""
    return obtener_por_id(
        gestor_estudiantes,
        Estudiante,
        id_registro
    )


def buscar_estudiantes(termino):
    """Busca estudiantes por sus datos."""
    return buscar(
        gestor_estudiantes,
        Estudiante,
        termino,
        CAMPOS_ESTUDIANTE
    )


def actualizar_estudiante(id_registro, cambios):
    """Actualiza la información de un estudiante."""
    estudiante = obtener_estudiante(id_registro)

    if estudiante is None:
        return False, "Estudiante no encontrado."

    datos = estudiante.a_diccionario()

    datos.update({
        campo: valor
        for campo, valor in cambios.items()
        if campo in CAMPOS_ESTUDIANTE
    })

    error = validar_estudiante(datos, estudiante.id)

    if error:
        return False, error

    actualizado = Estudiante.desde_diccionario(datos)
    reemplazar(gestor_estudiantes, actualizado)

    return True, "Estudiante actualizado correctamente."


def eliminar_estudiante(id_registro):
    """Elimina un estudiante sin matrículas asociadas."""

    if any(
        matricula.estudiante_id == int(id_registro)
        for matricula in obtener_matriculas()
    ):
        return (
            False,
            "No se puede eliminar: tiene matrículas asociadas."
        )

    if eliminar(gestor_estudiantes, id_registro):
        return True, "Estudiante eliminado correctamente."

    return False, "Estudiante no encontrado."


# ==========================================================
# GESTIÓN DE MATERIAS
# ==========================================================

CAMPOS_MATERIA = (
    "nombre",
    "codigo",
    "creditos",
    "cupos"
)


def codigos_registrados(excepto_id=None):
    """Obtiene los códigos de materias existentes."""
    return {
        registro["codigo"].strip().upper()
        for registro in gestor_materias.leer()
        if registro["id"] != excepto_id
    }


def validar_materia(datos, id_actual=None):
    """Valida los datos de una materia."""

    nombre = str(datos.get("nombre", "")).strip()
    codigo = str(datos.get("codigo", "")).strip().upper()

    if not nombre or not codigo:
        return "El nombre y código son obligatorios."

    if codigo in codigos_registrados(id_actual):
        return "El código de materia ya existe."

    try:
        creditos = int(datos["creditos"])
        cupos = int(datos["cupos"])

    except (ValueError, TypeError, KeyError):
        return "Los créditos y cupos deben ser enteros."

    if not 1 <= creditos <= 10:
        return "Los créditos deben estar entre 1 y 10."

    if not 0 <= cupos <= Materia.CUPOS_MAXIMOS:
        return (
            f"Los cupos deben estar entre 0 y "
            f"{Materia.CUPOS_MAXIMOS}."
        )

    return None


def crear_materia(datos):
    """Registra una nueva materia."""
    error = validar_materia(datos)

    if error:
        return False, error

    materia = Materia(
        siguiente_id(gestor_materias),
        str(datos["nombre"]).strip(),
        str(datos["codigo"]).strip(),
        datos["creditos"],
        datos["cupos"]
    )

    guardar_nuevo(gestor_materias, materia)
    return True, "Materia registrada correctamente."


def obtener_materias():
    """Devuelve todas las materias."""
    return leer_objetos(gestor_materias, Materia)


def obtener_materia(id_registro):
    """Obtiene una materia por su ID."""
    return obtener_por_id(
        gestor_materias,
        Materia,
        id_registro
    )


def buscar_materias(termino):
    """Busca materias por nombre o código."""
    return buscar(
        gestor_materias,
        Materia,
        termino,
        ("nombre", "codigo")
    )


def materias_sin_cupo():
    """Obtiene las materias sin cupos disponibles."""
    return [
        materia
        for materia in obtener_materias()
        if not materia.hay_cupo()
    ]


def actualizar_materia(id_registro, cambios):
    """Actualiza los datos de una materia."""
    materia = obtener_materia(id_registro)

    if materia is None:
        return False, "Materia no encontrada."

    datos = materia.a_diccionario()

    datos.update({
        campo: valor
        for campo, valor in cambios.items()
        if campo in CAMPOS_MATERIA
    })

    error = validar_materia(datos, materia.id)

    if error:
        return False, error

    ocupadas = sum(
        matricula.materia_id == materia.id
        for matricula in obtener_matriculas()
    )

    if int(datos["cupos"]) + ocupadas > Materia.CUPOS_MAXIMOS:
        return (
            False,
            "Los cupos disponibles y ocupados exceden "
            "el máximo permitido."
        )

    actualizada = Materia.desde_diccionario(datos)
    reemplazar(gestor_materias, actualizada)

    return True, "Materia actualizada correctamente."


def eliminar_materia(id_registro):
    """Elimina una materia sin matrículas asociadas."""

    if any(
        matricula.materia_id == int(id_registro)
        for matricula in obtener_matriculas()
    ):
        return (
            False,
            "No se puede eliminar: tiene matrículas asociadas."
        )

    if eliminar(gestor_materias, id_registro):
        return True, "Materia eliminada correctamente."

    return False, "Materia no encontrada."


# ==========================================================
# GESTIÓN DE MATRÍCULAS
# ==========================================================

def crear_matricula(datos):
    """Matricula un estudiante y descuenta un cupo."""

    try:
        estudiante_id = int(datos["estudiante_id"])
        materia_id = int(datos["materia_id"])
        periodo = str(datos["periodo"]).strip()
        nota = float(datos.get("nota", 0))

    except (ValueError, TypeError, KeyError):
        return False, "Datos de matrícula inválidos."

    if not periodo:
        return False, "El período académico es obligatorio."

    if estudiante_id not in ids_registrados(gestor_estudiantes):
        return False, "El estudiante no existe."

    materia = obtener_materia(materia_id)

    if materia is None:
        return False, "La materia no existe."

    if not materia.hay_cupo():
        return False, "La materia no tiene cupos disponibles."

    if not Materia.es_nota_valida(nota):
        return False, "La nota debe estar entre 0 y 20."

    duplicada = any(
        matricula.estudiante_id == estudiante_id
        and matricula.materia_id == materia_id
        and matricula.periodo.casefold() == periodo.casefold()
        for matricula in obtener_matriculas()
    )

    if duplicada:
        return (
            False,
            "El estudiante ya está matriculado en "
            "esa materia durante este período."
        )

    matricula = Matricula(
        siguiente_id(gestor_matriculas),
        estudiante_id,
        materia_id,
        periodo,
        nota,
        date.today().isoformat()
    )

    if not materia.ocupar_cupo():
        return False, "No se pudo reservar el cupo."

    # Guardar matrícula y actualizar cupos.
    # Ambos archivos deben mantenerse sincronizados.
    reemplazar(gestor_materias, materia)
    guardar_nuevo(gestor_matriculas, matricula)

    return True, "Matrícula registrada y cupo descontado."


def obtener_matriculas():
    """Devuelve todas las matrículas."""
    return leer_objetos(gestor_matriculas, Matricula)


def obtener_matricula(id_registro):
    """Obtiene una matrícula por su ID."""
    return obtener_por_id(
        gestor_matriculas,
        Matricula,
        id_registro
    )


def registrar_nota(id_registro, nota):
    """Registra la calificación de una matrícula."""
    matricula = obtener_matricula(id_registro)

    if matricula is None:
        return False, "Matrícula no encontrada."

    if not Materia.es_nota_valida(nota):
        return False, "La nota debe estar entre 0 y 20."

    matricula.nota = float(nota)
    reemplazar(gestor_matriculas, matricula)

    return True, "Calificación registrada correctamente."


def retirar_matricula(id_registro):
    """Retira una matrícula y recupera el cupo."""
    matricula = obtener_matricula(id_registro)

    if matricula is None:
        return False, "Matrícula no encontrada."

    materia = obtener_materia(matricula.materia_id)

    if materia is not None:
        if not materia.liberar_cupo():
            return False, "No se pudo liberar el cupo."

        reemplazar(gestor_materias, materia)

    eliminar(gestor_matriculas, matricula.id)

    return True, "Matrícula retirada correctamente."


# ==========================================================
# CERTIFICADOS ACADÉMICOS
# ==========================================================

def certificado(id_registro):
    """Genera un certificado académico en texto."""
    matricula = obtener_matricula(id_registro)

    if matricula is None:
        return None

    estudiantes = indice_por_id(obtener_estudiantes())
    materias = indice_por_id(obtener_materias())

    estudiante = estudiantes.get(matricula.estudiante_id)
    materia = materias.get(matricula.materia_id)

    if estudiante is None or materia is None:
        return None

    return (
        "\n========================================\n"
        "         CERTIFICADO ACADÉMICO\n"
        "========================================\n"
        f"Certificado N.º: {matricula.id}\n"
        f"Fecha: {matricula.fecha}\n"
        f"Período: {matricula.periodo}\n"
        "----------------------------------------\n"
        f"Estudiante: {estudiante.nombre} "
        f"{estudiante.apellido}\n"
        f"Carnet: {estudiante.carnet}\n"
        f"Carrera: {estudiante.carrera}\n"
        "----------------------------------------\n"
        f"Materia: {materia.nombre}\n"
        f"Código: {materia.codigo}\n"
        f"Créditos: {materia.creditos}\n"
        f"Calificación: {matricula.nota:g}/20\n"
        f"Estado: {matricula.estado()}\n"
        "========================================"
    )


# ==========================================================
# ESTADÍSTICAS ACADÉMICAS
# ==========================================================

def matriculas_por_estudiante():
    """Agrupa las matrículas por estudiante."""
    grupos = {}

    for matricula in obtener_matriculas():
        grupos.setdefault(
            matricula.estudiante_id,
            []
        ).append(matricula)

    return grupos


def promedio_de_estudiante(id_registro):
    """Calcula el promedio de notas de un estudiante."""
    registros = matriculas_por_estudiante().get(
        int(id_registro),
        []
    )

    if not registros:
        return None

    total = sum(
        matricula.nota
        for matricula in registros
    )

    return total / len(registros)


def resumen():
    """Devuelve las estadísticas generales del sistema."""
    estudiantes = obtener_estudiantes()
    matriculas = obtener_matriculas()

    carreras = sorted({
        estudiante.carrera
        for estudiante in estudiantes
        if estudiante.carrera
    })

    aprobadas = sum(
        matricula.esta_aprobada()
        for matricula in matriculas
    )

    return {
        "estudiantes": len(estudiantes),
        "carreras": carreras,
        "sin_cupo": materias_sin_cupo(),
        "aprobadas": aprobadas
    }
